package com.dude.musicapp;

import junit.framework.TestCase;

public class BuildConfigTest extends TestCase {

}