package com.dude.musicapp;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    Button play,pause,stop;
    MediaPlayer mediaPlayer = MediaPlayer.create(getApplicationContext(),R.raw.song );
    int pausePosition;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
    public void play(View view){
        if(mediaPlayer==null) {
            mediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.song );
            mediaPlayer.start();
        } else if (!mediaPlayer.isPlaying()) {

            mediaPlayer.seekTo(pausePosition);
            mediaPlayer.start();
        }

    }
    public void pause(View view){
        if(mediaPlayer!=null){
            mediaPlayer.pause();
            pausePosition=mediaPlayer.getCurrentPosition();
        }

    }
    public void stop(View view){
        if(mediaPlayer!=null) {
            mediaPlayer.stop();
            mediaPlayer=null;
        }
    }

}